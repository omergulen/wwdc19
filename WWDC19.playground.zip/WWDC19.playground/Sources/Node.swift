import UIKit

public class Node {
    
    var question : String
    var answer : String
    var node : TreeNode<String>
    var view = UIView(frame: CGRect(x:0, y: 0, width: 130, height: 130))
    var answerLabel = UILabel()
    var questionLabel = UILabel()
    
    public init(ans: String, que: String, n: TreeNode<String>){
        question = que
        answer = ans
        node = n
        initializeView()
    }
    
    private func initializeView(){
        answerLabel.frame = CGRect(x: 0, y:0, width: 128, height: 64)
        answerLabel.backgroundColor = .white
        answerLabel.textColor = .black
        answerLabel.textAlignment = .center
        answerLabel.text = answer
        answerLabel.layer.borderWidth = 3
        answerLabel.layer.masksToBounds = true
        answerLabel.layer.cornerRadius = 10
        answerLabel.layer.borderColor = UIColor.black.cgColor
        answerLabel.layer.maskedCorners = [ .layerMinXMinYCorner, .layerMaxXMinYCorner ]
        answerLabel.numberOfLines = 0
        answerLabel.lineBreakMode = .byWordWrapping
        answerLabel.font = UIFont.systemFont(ofSize: 15.0)
        
        questionLabel.frame = CGRect(x: 0, y:61, width: 128, height: 64)
        
        if (node.isLeaf()){
            questionLabel.backgroundColor = .green
        } else {
            questionLabel.backgroundColor = UIColor.orange
        }
        questionLabel.textColor = .black
        questionLabel.textAlignment = .center
        questionLabel.text = question
        questionLabel.layer.borderWidth = 3
        questionLabel.layer.masksToBounds = true
        questionLabel.layer.cornerRadius = 10
        questionLabel.layer.borderColor = UIColor.black.cgColor
        questionLabel.layer.maskedCorners = [ .layerMinXMaxYCorner, .layerMaxXMaxYCorner ]
        questionLabel.numberOfLines = 0
        questionLabel.lineBreakMode = .byWordWrapping
        questionLabel.font = UIFont.systemFont(ofSize: 15.0)
        
        view.addSubview(answerLabel)
        view.addSubview(questionLabel)
    }
    
    public func getView() -> UIView {
        return view
    }
    
    public func setOffset(x: Int, y: Int) {
        view.center.x = CGFloat(x)
        view.center.y = CGFloat(y)
    }
    
    public func drawLineFromPoint(start : CGPoint, toPoint end:CGPoint, ofColor lineColor: UIColor, inView view:UIView) {
        
        //design the path
        let path = UIBezierPath()
        path.move(to: start)
        path.addLine(to: end)
        
        //design path in layer
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = 1.0
        
        view.layer.addSublayer(shapeLayer)
    }
    
    public func makeSeleted(){
        UIView.animate(withDuration: 5.0, delay: 0.0, options:[.repeat, .autoreverse], animations: {
            self.answerLabel.backgroundColor = .black
            self.answerLabel.textColor = .orange
        }, completion:nil)
        
    }
    
    public func makeUnselected(){
        answerLabel.backgroundColor = .black
        answerLabel.textColor = .white
    }
    
    public func makeFinal(){
        answerLabel.backgroundColor = .black
        answerLabel.textColor = .green
    }
    
    public func reset(){
        answerLabel.backgroundColor = .white
        answerLabel.textColor = .black
    }
    
}

import UIKit

class ScrollingViewController : UIViewController {
    
    var treeView = UIView()
    
    public func setTreeView(tv: UIView){
        treeView = tv
    }
    
    override func loadView() {
        
        let scrollView = UIScrollView(frame: CGRect(x: 0, y: 0, width: 768, height: 512))
        scrollView.contentSize = treeView.frame.size
        scrollView.addSubview(treeView)
        scrollView.flashScrollIndicators()
        scrollView.backgroundColor = .gray
        scrollView.setContentOffset(CGPoint(x: 550, y: 0), animated: true)
        
        self.view = scrollView
    }
}

public class Tree {
    
    public var currentNode: TreeNode<String>
    public var rootNode: TreeNode<String>
    
    public init(currentNode: TreeNode<String>){
        self.currentNode = currentNode
        self.rootNode = currentNode
    }
    
    public init(){
        currentNode = TreeNode(value: "")
        rootNode = TreeNode(value: "")
    }
    
    public func getParent() -> TreeNode<String> {
        return currentNode.parent ?? currentNode
    }
    
    public func getInput(val: String, man: Manager) -> String {
        let trimmedVal = val.trimmingCharacters(in: .whitespacesAndNewlines)
        if (trimmedVal == "root"){
            let nextTempNode = man.search(el: rootNode)
            man.reset(el: rootNode)
            
            nextTempNode.makeSeleted()
            currentNode = rootNode
            return "Successful reset."
            
        }
            
        if (trimmedVal.split(separator: ".").count == 2){
            if (trimmedVal.split(separator: ".")[0] == "currentNode"){
                if (trimmedVal.split(separator: ".")[1] == "parent"){
                    return goBack(man: man)
                } else {
                    return goNext(val: trimmedVal.split(separator: ".")[1].description, man: man)
                }
            }
        }
        
        return "Wrong format!"
    }
    
    private func goBack(man: Manager) -> String{
        if (currentNode.parent != nil){
            
            let nextTempNode = man.search(el: currentNode.parent!)
            let currentTempNode = man.search(el: currentNode)
            
            currentTempNode.reset()
            nextTempNode.makeSeleted()
            
            currentNode = currentNode.parent!
            return "Returned back to the parent."
        } else {
            return "Root has no parent."
        }
    }
    
    private func goNext(val: String, man: Manager) -> String {
        if let tempNode = currentNode.search(val) {
            if (currentNode.children.contains(where: { $0 === tempNode })){
                
                if (tempNode.isLeaf()){
                    let nextTempNode = man.search(el: tempNode)
                    let currentTempNode = man.search(el: currentNode)
                    
                    currentTempNode.makeUnselected()
                    nextTempNode.makeFinal()
                    currentNode = tempNode
                    
                    return "Moved into the final node of this journey!\nYour coffee is \(nextTempNode.question)!"
                } else {
                    let nextTempNode = man.search(el: tempNode)
                    let currentTempNode = man.search(el: currentNode)
                    
                    currentTempNode.makeUnselected()
                    nextTempNode.makeSeleted()
                    currentNode = tempNode
                    return "Moved into next node."
                }
            } else {
                return "Not in the children of current node."
            }
        } else {
            return "Given node is not found down below!"
        }
    }
}

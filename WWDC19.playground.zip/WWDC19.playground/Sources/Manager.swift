import UIKit

public class Manager: UIViewController {
    
    var containerView = UIView()
    var label = UILabel()
    var textInput = UITextField()
    var tree = Tree()
    var listOfNodes = [Node]()
    
    public override func viewDidLoad() {
        initUIView()
        self.view = containerView
    }
    
    private func initUIView(){
        containerView = UIView(frame: CGRect(x:0, y:0, width: 768, height: 924))
        containerView.backgroundColor = .black
        initTree()
        initInputView()
    }
    
    private func initInputView(){
        let inputView = UIView(frame: CGRect(x:0, y:512, width: 768, height: 512))
        inputView.backgroundColor = UIColor.darkGray
        initInputObjects(inputView: inputView)
        containerView.addSubview(inputView)
    }
    
    private func initInputObjects(inputView: UIView){
        label.frame = CGRect(x: 130, y:30, width: 510, height: 50)
        let currentNodeLabel = UILabel(frame: CGRect(x: 130, y:100, width: 200, height: 50))
        
        
        label.text = "This is your status message box."
        label.textColor = .white
        label.textAlignment = .center
        label.numberOfLines = 0
        label.lineBreakMode = .byWordWrapping
        label.font = UIFont.systemFont(ofSize: 20.0)
        
        currentNodeLabel.text = "currentNode = "
        currentNodeLabel.textColor = .white
        
        
        textInput.frame = CGRect(x: 250, y: 100, width: 300, height: 50)
        textInput.placeholder = "code here"
        textInput.backgroundColor = .white
        textInput.textColor = UIColor.gray
        textInput.textAlignment = .center
        textInput.layer.borderWidth = 3
        textInput.layer.masksToBounds = true
        textInput.layer.cornerRadius = 10
        textInput.layer.borderColor = UIColor.gray.cgColor
        textInput.font = UIFont.systemFont(ofSize: 15.0)
        
        inputView.addSubview(label)
        inputView.addSubview(currentNodeLabel)
        inputView.addSubview(textInput)
    }
    
    @objc public func buttonTapped() {
        
        label.text = tree.getInput(val: textInput.text!, man: self)
    }
    
    public func search(el: TreeNode<String>) -> Node {
        
        for n in listOfNodes {
            if (n.node.value == el.value){
                return n;
            }
        }
        
        return Node(ans: "", que: "", n: TreeNode<String>(value: ""))
    }
    
    public func reset(el: TreeNode<String>){
        for n in listOfNodes {
            if (n.node.value != el.value){
                n.reset()
            }
        }
    }
    
    private func initTree(){
        let treeView = UIView(frame: CGRect(x:0, y:100, width: 2048, height: 2048))
        initNodes(treeView: treeView)
        let scvw = ScrollingViewController()
        scvw.setTreeView(tv: treeView)
        containerView.addSubview(scvw.view)
    }
    
    // SORRY, SO MUCH HARDCODED DATA :(
    private func initNodes(treeView: UIView){
        
        // TreeNode initializations
        let root = TreeNode<String>(value: "start")
        let answerNodeYes = TreeNode<String>(value: "yes")
        let answerNodeNo = TreeNode<String>(value: "no")
        let answerNodeMiddle = TreeNode<String>(value: "middle")
        let answerNodeZero = TreeNode<String>(value: "0percent")
        let answerNodeTwenty = TreeNode<String>(value: "20percent")
        let answerNodeForty = TreeNode<String>(value: "40percent")
        let answerNodeSixty = TreeNode<String>(value: "60percent")
        let answerNodeHundred = TreeNode<String>(value: "100percent")
        let answerNodeIceCream = TreeNode<String>(value: "iceCream")
        let answerNodeCream = TreeNode<String>(value: "cream")
        let answerNodeMilkFroth = TreeNode<String>(value: "milkFroth")
        let answerNodeMilk = TreeNode<String>(value: "milk")
        let answerNodeCoffee = TreeNode<String>(value: "coffee")
        let answerNodeLight = TreeNode<String>(value: "light")
        let answerNodeIntense = TreeNode<String>(value: "intense")
        let answerNodeFrothy = TreeNode<String>(value: "frothy")
        let answerNodeCreamy = TreeNode<String>(value: "creamy")
        let answerNodeHot = TreeNode<String>(value: "hot")
        let answerNodeCold = TreeNode<String>(value: "cold")
        let answerNodeChocolate = TreeNode<String>(value: "chocolate")
        let answerNodeCaramel = TreeNode<String>(value: "caramel")
        let answerNodeWhiteChocolate = TreeNode<String>(value: "whiteChocolate")
        let answerNodeNut = TreeNode<String>(value: "nut")
        let answerNodeNoFlavor = TreeNode<String>(value: "noFlavor")
        let answerNodeIceChocolate = TreeNode<String>(value: "chocolate")
        let answerNodeIceCaramel = TreeNode<String>(value: "caramel")
        let answerNodeIceWhiteChocolate = TreeNode<String>(value: "whiteChocolate")
        let answerNodeIceNut = TreeNode<String>(value: "nut")
        let answerNodeIceNoFlavor = TreeNode<String>(value: "noFlavor")
    
        // TreeNode connections
        root.addChild(answerNodeYes)
        root.addChild(answerNodeNo)
        root.addChild(answerNodeMiddle)
        
        answerNodeNo.addChild(answerNodeZero)
        answerNodeNo.addChild(answerNodeTwenty)
        answerNodeNo.addChild(answerNodeForty)
        answerNodeNo.addChild(answerNodeSixty)
        answerNodeNo.addChild(answerNodeHundred)
        
        answerNodeMiddle.addChild(answerNodeIceCream)
        answerNodeMiddle.addChild(answerNodeCream)
        answerNodeMiddle.addChild(answerNodeMilkFroth)
        
        answerNodeYes.addChild(answerNodeMilk)
        answerNodeYes.addChild(answerNodeCoffee)
        
        answerNodeCoffee.addChild(answerNodeLight)
        answerNodeCoffee.addChild(answerNodeIntense)
        
        answerNodeMilk.addChild(answerNodeFrothy)
        answerNodeMilk.addChild(answerNodeCreamy)
        
        answerNodeCreamy.addChild(answerNodeHot)
        answerNodeCreamy.addChild(answerNodeCold)
        
        answerNodeHot.addChild(answerNodeChocolate)
        answerNodeHot.addChild(answerNodeWhiteChocolate)
        answerNodeHot.addChild(answerNodeNut)
        answerNodeHot.addChild(answerNodeNoFlavor)
        answerNodeHot.addChild(answerNodeCaramel)
        
        answerNodeHot.addChild(answerNodeIceChocolate)
        answerNodeHot.addChild(answerNodeIceWhiteChocolate)
        answerNodeHot.addChild(answerNodeIceNut)
        answerNodeHot.addChild(answerNodeIceNoFlavor)
        answerNodeHot.addChild(answerNodeIceCaramel)
        
        
        // Node initializations
        let milkNode = Node(ans: "START THE JOURNEY!", que: "Milk?", n: root)
        let instensityNode = Node(ans: "Yes", que: "Which one should be more intense?", n: answerNodeYes)
        let ontheTopNode = Node(ans: "Middle", que: "On the top", n: answerNodeMiddle)
        let coffeeIntensityNode = Node(ans: "No", que: "Coffee intensity", n: answerNodeNo)
        let zeroNode = Node(ans: "0percent", que: "Americano", n: answerNodeZero)
        let twentyNode = Node(ans: "20percent", que: "Lungo", n: answerNodeTwenty)
        let fortyNode = Node(ans: "40percent", que: "Espresso", n: answerNodeForty)
        let sixtyNode = Node(ans: "60percent", que: "Ristretto", n: answerNodeSixty)
        let hundredNode = Node(ans: "100percent", que: "Red Eye", n: answerNodeHundred)
        let iceCreamNode = Node(ans: "Ice Cream", que: "Affogato", n: answerNodeIceCream)
        let creamNode = Node(ans: "Cream", que: "Espress Con Panna", n: answerNodeCream)
        let milkFrothNode = Node(ans: "Milk Froth", que: "Macchiato", n: answerNodeMilkFroth)
        let moreMilkNode = Node(ans: "Milk", que: "Milk Consistency?", n: answerNodeMilk)
        let moreCoffeeNode = Node(ans: "Coffee", que: "Instensity of the coffee?", n: answerNodeCoffee)
        let flatWhiteNode = Node(ans: "Light", que: "Flat White", n: answerNodeLight)
        let cortadoNode = Node(ans: "Intense", que: "Cortado", n: answerNodeIntense)
        let frothyMilkNode = Node(ans: "Frothy", que: "Cappuccino", n: answerNodeFrothy)
        let creamyMilkNode = Node(ans: "Creamy", que: "Hot or cold?", n: answerNodeCreamy)
        let hotNode = Node(ans: "Hot", que: "Flavor?", n: answerNodeHot)
        let coldNode = Node(ans: "Cold", que: "Flavor?", n: answerNodeCold)
        let hotChocolateNode = Node(ans: "Chocolate", que: "Mocha", n: answerNodeChocolate)
        let hotCaramelNode = Node(ans: "Caramel", que: "Caramel Latte", n: answerNodeCaramel)
        let hotWhiteChocolateNode = Node(ans: "White Chocolate", que: "White Chocolate Mocha", n: answerNodeWhiteChocolate)
        let hotNutNode = Node(ans: "Nut", que: "Toffee Nut Latte", n: answerNodeNut)
        let hotNoFlavorNode = Node(ans: "No flavor", que: "Latte", n: answerNodeNoFlavor)
        let icedChocolateNode = Node(ans: "Chocolate", que: "Iced Mocha", n: answerNodeIceChocolate)
        let icedCaramelNode = Node(ans: "Caramel", que: "Iced Caramel Latte", n: answerNodeIceCaramel)
        let icedWhiteChocolateNode = Node(ans: "White Chocolate", que: "Iced White Chocolate Mocha", n: answerNodeIceWhiteChocolate)
        let icedNutNode = Node(ans: "Nut", que: "Iced Toffee Nut Latte", n: answerNodeIceNut)
        let icedNoFlavorNode = Node(ans: "No flavor", que: "Iced Latte", n: answerNodeIceNoFlavor)

        // Initial selected
        milkNode.makeSeleted()
        
        // Adding Nodes to the list
        listOfNodes.append(milkNode)
        listOfNodes.append(instensityNode)
        listOfNodes.append(ontheTopNode)
        listOfNodes.append(coffeeIntensityNode)
        listOfNodes.append(zeroNode)
        listOfNodes.append(twentyNode)
        listOfNodes.append(fortyNode)
        listOfNodes.append(sixtyNode)
        listOfNodes.append(hundredNode)
        listOfNodes.append(iceCreamNode)
        listOfNodes.append(creamNode)
        listOfNodes.append(milkFrothNode)
        listOfNodes.append(moreMilkNode)
        listOfNodes.append(moreCoffeeNode)
        listOfNodes.append(flatWhiteNode)
        listOfNodes.append(cortadoNode)
        listOfNodes.append(frothyMilkNode)
        listOfNodes.append(creamyMilkNode)
        listOfNodes.append(hotNode)
        listOfNodes.append(coldNode)
        listOfNodes.append(hotChocolateNode)
        listOfNodes.append(hotCaramelNode)
        listOfNodes.append(hotWhiteChocolateNode)
        listOfNodes.append(hotNutNode)
        listOfNodes.append(hotNoFlavorNode)
        listOfNodes.append(icedChocolateNode)
        listOfNodes.append(icedCaramelNode)
        listOfNodes.append(icedWhiteChocolateNode)
        listOfNodes.append(icedNutNode)
        listOfNodes.append(icedNoFlavorNode)
        
        // Setting up the tree
        tree = Tree(currentNode: root)
        
        // Moving Nodes in the view
        milkNode.setOffset(x: 950, y: 10)
        instensityNode.setOffset(x: 810, y: 140)
        ontheTopNode.setOffset(x: 950, y: 140)
        coffeeIntensityNode.setOffset(x: 1085, y: 140)
        zeroNode.setOffset(x: 1200, y: 400)
        twentyNode.setOffset(x: 1335, y: 400)
        fortyNode.setOffset(x: 1470, y: 330)
        sixtyNode.setOffset(x: 1470, y: 200)
        hundredNode.setOffset(x: 1470, y: 70)
        iceCreamNode.setOffset(x: 810, y: 520)
        creamNode.setOffset(x: 945, y: 520)
        milkFrothNode.setOffset(x: 1080, y: 520)
        moreCoffeeNode.setOffset(x: 250, y: 350)
        moreMilkNode.setOffset(x: 600, y: 350)
        cortadoNode.setOffset(x: 180, y: 500)
        flatWhiteNode.setOffset(x: 320, y: 500)
        frothyMilkNode.setOffset(x: 530, y: 500)
        creamyMilkNode.setOffset(x: 670, y: 500)
        hotNode.setOffset(x: 530, y: 850)
        coldNode.setOffset(x: 830, y: 850)
        hotChocolateNode.setOffset(x: 150, y: 1000)
        hotCaramelNode.setOffset(x: 150, y: 1150)
        hotWhiteChocolateNode.setOffset(x: 300, y: 1150)
        hotNutNode.setOffset(x: 450, y: 1150)
        hotNoFlavorNode.setOffset(x: 600, y: 1150)
        icedChocolateNode.setOffset(x: 750, y: 1150)
        icedCaramelNode.setOffset(x: 880, y: 1150)
        icedNutNode.setOffset(x: 1010, y: 1150)
        icedWhiteChocolateNode.setOffset(x: 1140, y: 1030)
        icedNoFlavorNode.setOffset(x: 1140, y: 900)
        
        // Drawing lines from roots to children
        milkNode.drawLineFromPoint(start: milkNode.getView().center, toPoint: instensityNode.getView().center, ofColor: UIColor.black, inView: treeView)
        milkNode.drawLineFromPoint(start: milkNode.getView().center, toPoint: ontheTopNode.getView().center, ofColor: UIColor.black, inView: treeView)
        milkNode.drawLineFromPoint(start: milkNode.getView().center, toPoint: coffeeIntensityNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        coffeeIntensityNode.drawLineFromPoint(start: coffeeIntensityNode.getView().center, toPoint: zeroNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coffeeIntensityNode.drawLineFromPoint(start: coffeeIntensityNode.getView().center, toPoint: twentyNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coffeeIntensityNode.drawLineFromPoint(start: coffeeIntensityNode.getView().center, toPoint: fortyNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coffeeIntensityNode.drawLineFromPoint(start: coffeeIntensityNode.getView().center, toPoint: sixtyNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coffeeIntensityNode.drawLineFromPoint(start: coffeeIntensityNode.getView().center, toPoint: hundredNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        ontheTopNode.drawLineFromPoint(start: ontheTopNode.getView().center, toPoint: iceCreamNode.getView().center, ofColor: UIColor.black, inView: treeView)
        ontheTopNode.drawLineFromPoint(start: ontheTopNode.getView().center, toPoint: creamNode.getView().center, ofColor: UIColor.black, inView: treeView)
        ontheTopNode.drawLineFromPoint(start: ontheTopNode.getView().center, toPoint: milkFrothNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        instensityNode.drawLineFromPoint(start: instensityNode.getView().center, toPoint: moreMilkNode.getView().center, ofColor: UIColor.black, inView: treeView)
        instensityNode.drawLineFromPoint(start: instensityNode.getView().center, toPoint: moreCoffeeNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        moreCoffeeNode.drawLineFromPoint(start: moreCoffeeNode.getView().center, toPoint: flatWhiteNode.getView().center, ofColor: UIColor.black, inView: treeView)
        moreCoffeeNode.drawLineFromPoint(start: moreCoffeeNode.getView().center, toPoint: cortadoNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        moreMilkNode.drawLineFromPoint(start: moreMilkNode.getView().center, toPoint: frothyMilkNode.getView().center, ofColor: UIColor.black, inView: treeView)
        moreMilkNode.drawLineFromPoint(start: moreMilkNode.getView().center, toPoint: creamyMilkNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        creamyMilkNode.drawLineFromPoint(start: creamyMilkNode.getView().center, toPoint: hotNode.getView().center, ofColor: UIColor.black, inView: treeView)
        creamyMilkNode.drawLineFromPoint(start: creamyMilkNode.getView().center, toPoint: coldNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        hotNode.drawLineFromPoint(start: hotNode.getView().center, toPoint: hotChocolateNode.getView().center, ofColor: UIColor.black, inView: treeView)
        hotNode.drawLineFromPoint(start: hotNode.getView().center, toPoint: hotCaramelNode.getView().center, ofColor: UIColor.black, inView: treeView)
        hotNode.drawLineFromPoint(start: hotNode.getView().center, toPoint: hotNoFlavorNode.getView().center, ofColor: UIColor.black, inView: treeView)
        hotNode.drawLineFromPoint(start: hotNode.getView().center, toPoint: hotWhiteChocolateNode.getView().center, ofColor: UIColor.black, inView: treeView)
        hotNode.drawLineFromPoint(start: hotNode.getView().center, toPoint: hotNutNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        coldNode.drawLineFromPoint(start: coldNode.getView().center, toPoint: icedNoFlavorNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coldNode.drawLineFromPoint(start: coldNode.getView().center, toPoint: icedWhiteChocolateNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coldNode.drawLineFromPoint(start: coldNode.getView().center, toPoint: icedNutNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coldNode.drawLineFromPoint(start: coldNode.getView().center, toPoint: icedChocolateNode.getView().center, ofColor: UIColor.black, inView: treeView)
        coldNode.drawLineFromPoint(start: coldNode.getView().center, toPoint: icedCaramelNode.getView().center, ofColor: UIColor.black, inView: treeView)
        
        
        // Adding Nodes and lines to the view
        treeView.addSubview(milkNode.getView())
        treeView.addSubview(instensityNode.getView())
        treeView.addSubview(ontheTopNode.getView())
        treeView.addSubview(coffeeIntensityNode.getView())
        treeView.addSubview(zeroNode.getView())
        treeView.addSubview(twentyNode.getView())
        treeView.addSubview(fortyNode.getView())
        treeView.addSubview(sixtyNode.getView())
        treeView.addSubview(hundredNode.getView())
        treeView.addSubview(iceCreamNode.getView())
        treeView.addSubview(creamNode.getView())
        treeView.addSubview(milkFrothNode.getView())
        treeView.addSubview(moreCoffeeNode.getView())
        treeView.addSubview(moreMilkNode.getView())
        treeView.addSubview(flatWhiteNode.getView())
        treeView.addSubview(cortadoNode.getView())
        treeView.addSubview(frothyMilkNode.getView())
        treeView.addSubview(creamyMilkNode.getView())
        treeView.addSubview(hotNode.getView())
        treeView.addSubview(coldNode.getView())
        treeView.addSubview(hotChocolateNode.getView())
        treeView.addSubview(hotCaramelNode.getView())
        treeView.addSubview(hotNutNode.getView())
        treeView.addSubview(hotWhiteChocolateNode.getView())
        treeView.addSubview(hotNoFlavorNode.getView())
        treeView.addSubview(icedChocolateNode.getView())
        treeView.addSubview(icedCaramelNode.getView())
        treeView.addSubview(icedNutNode.getView())
        treeView.addSubview(icedWhiteChocolateNode.getView())
        treeView.addSubview(icedNoFlavorNode.getView())
    }
}



/*: Barista Tree
 
 # Barista Tree
 
 ## Find your best fitted coffee while coding and learning Tree Structure!
 
 ### Introduction
 
 Have you ever had problem with choosing a coffee? Not knowing all the fancy names to them, always ordering the same thing?
 This playground helps you choose a coffee suited by your needs, whilst teaching you the Tree Data Structure!
 Have fun playing while polishing your skills on the tree structure or learning it easily and visually from scratch.
 
 #### Tree
 
 Tree is a specified data structure. There are `node` s (in our case, question-answer pairs) and `edge` s (lines that connect nodes).
 
 
 The most-top node is called `root` node. Also, there are `children`. A child node is a node just down below of another node. If a node has child or children, that node is called the `parent` of its children nodes.
 
 A node is called the `leaf` when it doesn't have any child.
 
 - TIP: The root node doesn't have any parent.
 
 ### Challenge
 
 In this Playground your challenge is to find the coffee that fits you the best while coding and learning.
 
 ### Usage
 
 Top part of the node is the answer, and the bottom part is the question. Each answer leads to a new question until a leaf is reached.
 
 
 To navigate between nodes, simply access the node's  desired answer value. The node you are on is always called "currentNode" and it will light up on the screen to indicate which is your node; and you can make your choice by reaching one of currentNode's answers, as they are written on the screen. Be careful to only reach the lighted up node's answers, as that is your currentNode.
 
 
 Examples can be:
    `currentNode.yes`,
    `currentNode.milk`
 ...
 
 - `currentNode.milk`: To choose `Milk` as an answer
 
 
 - `root`: To reset and go back to the top, just type `root`
 
 
 - `currentNode.parent`: To go back just one step
 
 - `;` : Use ";" button as return
 
 
 Be careful to use `camelCase`!
 
 
 ### To Do
 Instead of giving a hard coded, premade tree; it should be more generic by allowing users to create their own trees. Add, remove methods should be included also.
 
 
 
*/
import UIKit
import PlaygroundSupport

var button = UIButton(type: .system)

button.frame = CGRect(x:555, y:612, width: 50, height: 50)
button.backgroundColor = .black
button.layer.cornerRadius = 10

button.setTitle(";", for: .normal)
button.setTitleColor(.white, for: .normal)

class ActionTarget {
    
    let closure: () -> ()
    
    init(closure: @escaping () -> ()) {
        self.closure = closure
    }
    
    @objc func action() {
        closure()
    }
}

let vc = Manager()

let target = ActionTarget {
    vc.buttonTapped()
}

button.addTarget(target, action: #selector(ActionTarget.action), for: .touchUpInside)

PlaygroundPage.current.needsIndefiniteExecution = true

vc.view.addSubview(button)
PlaygroundPage.current.liveView = vc.view
